﻿/*
 * Creado por SharpDevelop.
 * Usuario: andyc
 * Fecha: 28/05/2019
 * Hora: 19:13
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Licamba
{
	/// <summary>
	/// Description of FormMenu.
	/// </summary>
	public partial class FormMenu : Form
	{
		public FormMenu()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
